# shax — Neon Social

Qora fonli, neon ko‘k/binafsha uslubdagi, telefonlarga mos ijtimoiy tarmoq demo-sayti.

## Ishlaydigan demo imkoniyatlari
- Post joylash
- Like bosish
- Izoh qo‘shish
- Postlarni qidirish va ommabop postlar filtri
- Kuzatish tugmalari
- Postlar shu brauzerning `localStorage` xotirasida saqlanadi

## GitHub Pages orqali internetga chiqarish
1. GitHub.com saytiga kiring va hisobingizga kiring.
2. `New repository` tugmasini bosing.
3. Repository nomini `shax` deb kiriting. `Public` tanlang va `Create repository` bosing.
4. `Add file` → `Upload files` orqali `index.html` faylini yuklang va `Commit changes` bosing.
5. Repository ichida `Settings` → `Pages` bo‘limini oching.
6. `Build and deployment` ichida `Deploy from a branch` tanlang.
7. Branch: `main`, folder: `/(root)` tanlang va `Save` bosing.
8. Bir oz kuting. Sahifada ko‘rsatilgan `https://GITHUB-USERNAME.github.io/shax/` havolasi saytingiz bo‘ladi.

Agar repository nomi `USERNAME.github.io` bo‘lsa, havola `https://USERNAME.github.io/` ko‘rinishida bo‘ladi.

## Muhim
Bu frontend demo. `localStorage` tufayli postlar faqat shu brauzer va qurilmada saqlanadi; boshqa foydalanuvchilarga ko‘rinmaydi. Haqiqiy ro‘yxatdan o‘tish, login, umumiy postlar bazasi va moderatsiya uchun alohida backend hamda xavfsizlik sozlamalari kerak.
